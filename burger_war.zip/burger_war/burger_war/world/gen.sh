#!/bin/bash
set -o verbose
empy burger_field.world.em > burger_field.world

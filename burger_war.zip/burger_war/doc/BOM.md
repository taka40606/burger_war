| 名称 | メーカー | 型番 | 参考URL | 備考 |
---|---|---|---|---
| Turtlebot3 Burger | ROBOTIS | Turtlebot3 Burger | https://www.besttechnology.co.jp/modules/onlineshop/index.php?fct=photo&p=192 | | 
| NUC | Intel | NUC8i3BEK | https://www.amazon.co.jp/dp/B07JW4X5TL/ |  |
| メモリー<br>DDR4-2400 1.2V SO-DIMM | Transcend | JM2400HSB-8G | https://www.amazon.co.jp/dp/B072M7N989/ | 8GB |
| M.2 SSD | Western Digital | WDS250G2B0B | https://www.amazon.co.jp/dp/B073SBV3XX/ | 250GB |
| 電源ケーブル | Buffalo | BSACC0820BKA | https://www.amazon.co.jp/dp/B014GLJIMO/ | ロボットでは使用しないがインストール作業時に必要 |
| DCプラグ 5.5 x 2.5mm DCオス | Uxcell | ASINB07FTFHJXM | https://www.amazon.co.jp/dp/B07FTFHJXM | Intel NUC給電用<br>φ2.5(内径)-φ5.5(外径) |
| Webカメラ | Logicool | C270 | https://www.amazon.co.jp/dp/B003YUB660 |  |
| ラジコン用NiMHバッテリー | NASTIMA | NASTIMA 7.2V 4000mAh | https://www.amazon.co.jp/dp/B07789SDYY/ |  |
| DCDC | 千石電商 | DCCSU3-35V  | https://www.sengoku.co.jp/mod/sgk_cart/detail.php?code=EEHD-4DBT |  |
| ラジコン用バッテリーコネクター | イーグル模型 | 1104 | https://www.amazon.co.jp/dp/B006KA1A6M/ | JST LP-02-1 のアセンブリ品 |
| ラジコン用バッテリー充電器 | イーグル模型 | 3511 | https://www.amazon.co.jp/dp/B00F4Q0MBC |  |
